from django.contrib import admin
from .models import Poem
# Register your models here.

admin.site.register(Poem)
from django.apps import AppConfig


class PoemsConfig(AppConfig):
    name = 'poems'

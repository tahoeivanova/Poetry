from django.shortcuts import render, HttpResponseRedirect, reverse
from django.views.generic import ListView
from .models import Story
from .forms import StoryForm
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
# Create your views here.


class StoryView(LoginRequiredMixin, ListView):
    model = Story
    template_name = 'stories/stories.html'
    context_object_name = 'stories'

# @login_required
@user_passes_test(lambda user: user.is_superuser)
def story_add(request):
    if request.method == 'GET':
        form = StoryForm
        return render(request, 'stories/story_add.html', {'form': form})
    else:
        form = StoryForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('home'))
        else:
            return render(request, 'stories/story_add.html', {'form': form})